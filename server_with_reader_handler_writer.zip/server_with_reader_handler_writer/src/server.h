#ifndef _server_h_
#define _server_h_

#include "commen.h"

void start_server(const char *ip, unsigned short port);

void stop_server();

#endif // _server_h_

