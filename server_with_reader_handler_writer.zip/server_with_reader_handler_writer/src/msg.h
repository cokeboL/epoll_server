#ifndef _msg_h_
#define _msg_h_

#include "sock.h"

typedef struct SockMsg
{
	Sock *sock;     //Msg来源：sock->fd
	char *msg;    //消息体：去掉整个Msg的head四个字节
	uint16_t len;   //SockMsg.msg指向的buf长度
	uint16_t count;//引用计数
}SockMsg;

SockMsg *create_msg(Sock *sock);

#endif // _msg_h_
