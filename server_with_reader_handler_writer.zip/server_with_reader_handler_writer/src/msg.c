#include "commen.h"
#include "msg.h"

SockMsg *create_msg(Sock *sock, uint16_t len)
{
	
}