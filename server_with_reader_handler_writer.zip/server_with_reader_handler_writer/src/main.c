#include "server.h"

int main()
{
    start_server("127.0.0.1", 8888);

    return 0;
}
